More example for exclude, see [go-exclude](https://github.com/CatTail/go-exclude/tree/master/example).
