1.0.0 / 2014-11-27
===================

  * `make build` generate tar.gz package rather than raw binary
  * `git hooks update` will download and extract tar.gz
  * `git hooks update` will check [sermver](http://semver.org/) version compability (majoy version) before update
